﻿namespace HolisticHealthHub.Pages
{
    internal class NutritionixApiClient
    {
       
        private const string ApiKey = "121eddea703e52686c9bcf4464523848";
        private const string BaseUrl = "https://developer.nutritionix.com/admin/applications/1409624466810";

        public async Task<string> GetFoodNutrition(string upcCode)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(BaseUrl);

                var response = await client.GetAsync($"?upc={upcCode}&appId={ApiKey}&appKey={ApiKey}");
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    return result;
                }
                else
                {
                    // Handle error response
                    return null;
                }
            }
        }
    }
}