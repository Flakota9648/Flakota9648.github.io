using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;


namespace HolisticHealthHub.Pages
{
    //public class SpanekModel : PageModel
    //{
    //    private string FilePath = Path.Combine("Data", "spanky.txt"); // Cesta k textov�mu souboru pro ukl�d�n� d�lek sp�nku

    //    // Zde jsou p��klady tip� na zlep�en� sp�nku
    //    public List<string> TipyNaZlepseniSpanku { get; } = new List<string>
    //    {
    //        "Dodr�ujte pravideln� sp�nkov� re�im",
    //        "Vytvo�te si p�ed span�m relaxa�n� rutinu",
    //        "Omezte konzumaci kofeinu a alkoholu ve ve�ern�ch hodin�ch",
    //        "Zajist�te si vhodn� prost�ed� pro span� (ticho, tma, pohodln� postel)",
    //        "Vyhn�te se j�dlu t�sn� p�ed span�m",
    //        "Cvi�te pravideln�, ale vyhn�te se fyzick� aktivit� p��li� bl�zko k dob� sp�nku"
    //    };

    //    // Property pro data d�lek sp�nku
    //    public List<double> DataDelkySpanku => ReadSpankyFromFile();

    //    // Property pro pr�m�rnou d�lku sp�nku
    //    public double PrumernaDelkaSpanku => DataDelkySpanku.Any() ? DataDelkySpanku.Average() : 0;

    //    // Property pro celkov� po�et hodin sp�nku
    //    public double CelkovyPocetHodinSpanku => DataDelkySpanku.Sum();

    //    // Property pro vyhodnocen� kvality sp�nku
    //    public string HodnoceniKvalitySpanku
    //    {
    //        get
    //        {
    //            double doporucenaDelkaSpanku = 8; // P�edpokl�dan� doporu�en� d�lka sp�nku
    //            if (PrumernaDelkaSpanku >= doporucenaDelkaSpanku)
    //                return "Dobr� kvalita sp�nku";
    //            else
    //                return "N�zk� kvalita sp�nku";
    //        }
    //    }

    //    // Handler pro p�id�n� nov�ho z�znamu o sp�nku
    //    public IActionResult OnPostAddSpanek(double delkaSpanku)
    //    {
    //        using (StreamWriter sw = File.AppendText(FilePath))
    //        {
    //            sw.WriteLine(delkaSpanku); // Zapi� novou d�lku sp�nku do souboru
    //        }
    //        return RedirectToPage(); // P�esm�ruj zp�t na stejnou str�nku
    //    }

    //    // Metoda pro na�ten� dat d�lek sp�nku ze souboru
    //    private List<double> ReadSpankyFromFile()
    //    {
    //        if (File.Exists(FilePath))
    //        {
    //            return File.ReadAllLines(FilePath).Select(double.Parse).ToList();
    //        }
    //        else
    //        {
    //            return new List<double>();
    //        }
    //    }

    //    // Metoda pro vykreslen� grafu d�lek sp�nku
    //    public string VykreslitGraf()
    //    {
    //        string data = string.Join(",", DataDelkySpanku);
    //        string script = $@"
    //            var ctx = document.getElementById('grafSpanku').getContext('2d');
    //            var myChart = new Chart(ctx, {{
    //                type: 'line',
    //                data: {{
    //                    labels: ['1', '2', '3', '4', '5', '6', '7'],
    //                    datasets: [{{
    //                        label: 'D�lka sp�nku',
    //                        data: [{data}],
    //                        borderColor: 'rgba(75, 192, 192, 1)',
    //                        borderWidth: 1
    //                    }}]
    //                }},
    //                options: {{
    //                    scales: {{
    //                        y: {{
    //                            beginAtZero: true
    //                        }}
    //                    }}
    //                }}
    //            }});
    //        ";
    //        return script;
    //    }
    //}
}
