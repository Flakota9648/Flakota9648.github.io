﻿namespace HolisticHealthHub.Pages
{
    public class Emotion
    {
        public string Name { get; set; }
        public DateTime DateAdded { get; set; }
    }
}