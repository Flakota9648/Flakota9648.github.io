using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace HolisticHealthHub.Pages
{
    public class MeditaceModel : PageModel
    {
        // Prom�nn� pro sledov�n� zb�vaj�c�ho �asu meditace
        private TimeSpan RemainingTime;

        
        // Metoda pro spu�t�n� meditace s danou d�lkou
        public async Task<IActionResult> OnStartMeditationAsync(int meditationLength)
        {
            // Spu�t�n� �asova�e na 20 minut
            await Task.Delay(TimeSpan.FromMinutes(meditationLength));

            // Po uplynut� �asu provedeme dal�� akce, nap�. zobrazen� zpr�vy o dokon�en� meditace
            return new JsonResult(new { message = "Meditace byla dokon�ena." });
        }

        // Metoda pro z�sk�n� zb�vaj�c�ho �asu meditace
        public IActionResult OnGetRemainingTime()
        {
            // Vr�t�me zb�vaj�c� �as ve form�tu mm:ss
            return new JsonResult(new { remainingTime = RemainingTime.ToString(@"mm\:ss") });
        }

        // Metoda pro ukon�en� meditace
        public IActionResult OnEndMeditation()
        {
            // Ukon��me meditaci a vr�t�me zpr�vu
            return new JsonResult(new { message = "Meditation ended." });
        }



    }
}
