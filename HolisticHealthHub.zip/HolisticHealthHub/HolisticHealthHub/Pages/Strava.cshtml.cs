using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;

namespace HolisticHealthHub.Pages
{
    public class StravaModel : PageModel
    {
        // Ukl�d�n� do�asn� v pam�ti na stran� serveru
        private static List<FoodEntry> _foodEntries = new List<FoodEntry>();

        [BindProperty]
        public string FoodName { get; set; }

        [BindProperty]
        public int Calories { get; set; }

        public List<FoodEntry> FoodEntries { get { return _foodEntries; } }

        public int TotalCalories
        {
            get
            {
                int total = 0;
                foreach (var foodEntry in _foodEntries)
                {
                    total += foodEntry.Calories;
                }
                return total;
            }
        }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _foodEntries.Add(new FoodEntry { Name = FoodName, Calories = Calories });
            return RedirectToPage();
        }
    }

    public class FoodEntry
    {
        public string Name { get; set; }
        public int Calories { get; set; }
    }
}
