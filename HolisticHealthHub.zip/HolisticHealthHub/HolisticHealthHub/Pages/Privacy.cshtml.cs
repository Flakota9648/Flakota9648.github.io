﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolisticHealthHub.Pages
{
    public class PrivacyModel : PageModel
    {
        private readonly ILogger<PrivacyModel> _logger;

        public string CilOvoceAZeleniny { get; set; }
        public string CilCukru { get; set; }
        public string CilBilkovin { get; set; }
        public string DoporuceniStravovani { get; set; }

        public PrivacyModel(ILogger<PrivacyModel> logger)
        {
            _logger = logger;
        }

        public async Task OnGet(string odpovedStravovani, string cilOvoceAZeleniny, string cilCukru, string cilBilkovin)
        {
            if (!string.IsNullOrEmpty(odpovedStravovani))
            {
                // Zavolat algoritmus pro stravování s odpovědí uživatele
                DoporuceniStravovani = StravovaniAlgoritmus.DoporucitZmeny(odpovedStravovani);

                // Uložení cílů z parametrů do vlastností třídy
                CilOvoceAZeleniny = cilOvoceAZeleniny;
                CilCukru = cilCukru;
                CilBilkovin = cilBilkovin;
                // Uložení dalších cílů podle potřeby...

                // Získání nutričních informací o potravině
                var upcCode = "012345678912"; // Zadejte UPC kód potraviny
                var nutritionixApiClient = new NutritionixApiClient();
                var nutritionInfo = await nutritionixApiClient.GetFoodNutrition(upcCode);

                if (nutritionInfo != null)
                {
                    // Zpracování získaných nutričních informací
                    Console.WriteLine(nutritionInfo);
                }
                else
                {
                    // Něco se nepodařilo při získávání informací
                    Console.WriteLine("Nepodařilo se získat informace o výživě potraviny.");
                }
            }
        }
    }

    internal class StravovaniAlgoritmus
    {
        public static string DoporucitZmeny(string odpoved)
        {
            // Analyzovat odpověď uživatele a poskytnout doporučení
            if (odpoved == "Méně než jedna porce denně")
            {
                return "Zvyšte příjem ovoce a zeleniny na minimálně jednu porci denně. Začněte nejdříve s menším množstvím a postupně přejděte až na doporučenou denní dávku podle doporučení Světové zdravotnické organizace (WHO) = 450 gramů a více.";
            }
            else if (odpoved == "Více než tři porce denně")
            {
                return "Skvělé, máte zdravé stravovací návyky! Vypadá to, že jste typ člověka, který dbá na zdravý životní styl a stará se správně o své tělo. Nezapomeňte, jste to, co jíte.";
            }
            else
            {
                return "Pokud máte skutečně zájem o zlepšení stravovacích návyků, doporučuji konzumovat více ovoce a zeleniny. Tyto složky jsou nezbytné pro zdravé fungování lidského těla. Jsou především bohaté na vlákniny a živiny.";
            }
        }
    }
}

