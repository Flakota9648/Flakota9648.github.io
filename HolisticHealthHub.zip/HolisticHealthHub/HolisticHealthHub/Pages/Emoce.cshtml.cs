using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolisticHealthHub.Pages
{
    public class EmoceModel : PageModel
    {
        // Ukl�d�n� emoc� do�asn� v pam�ti na stran� serveru
        private static List<Emotion> _emotions = new List<Emotion>();

        [BindProperty]
        public string NewEmotion { get; set; }

        public List<Emotion> Emotions { get { return _emotions; } }

        [BindProperty(SupportsGet = true)]
        public string FilterByDate { get; set; }

        public List<Emotion> FilteredEmotions
        {
            get
            {
                if (string.IsNullOrEmpty(FilterByDate))
                {
                    return Emotions;
                }

                DateTime today = DateTime.Today;
                switch (FilterByDate)
                {
                    case "Today":
                        return Emotions.Where(e => e.DateAdded.Date == today).ToList();
                    case "ThisWeek":
                        DateTime startOfWeek = today.AddDays(-((int)today.DayOfWeek - (int)DayOfWeek.Monday));
                        DateTime endOfWeek = startOfWeek.AddDays(6);
                        return Emotions.Where(e => e.DateAdded.Date >= startOfWeek && e.DateAdded.Date <= endOfWeek).ToList();
                    case "ThisMonth":
                        DateTime startOfMonth = new DateTime(today.Year, today.Month, 1);
                        DateTime endOfMonth = startOfMonth.AddMonths(1).AddDays(-1);
                        return Emotions.Where(e => e.DateAdded.Date >= startOfMonth && e.DateAdded.Date <= endOfMonth).ToList();
                    default:
                        return Emotions;
                }
            }
        }

        public void OnGet()
        {
        }

        public IActionResult OnPostAddEmotion()
        {
            if (!string.IsNullOrEmpty(NewEmotion))
            {
                // P�idat novou emoci do seznamu
                _emotions.Add(new Emotion { Name = NewEmotion, DateAdded = DateTime.Now });

                // P�esm�rov�n� na stejnou str�nku
                return RedirectToPage();

            }

            // Pokud nebyla zad�na ��dn� emoce, z�stat na stejn� str�nce
            return Page();
        }
    }
}
