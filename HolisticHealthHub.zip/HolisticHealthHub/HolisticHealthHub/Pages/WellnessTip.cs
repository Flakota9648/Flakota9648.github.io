﻿namespace HolisticHealthHub.Pages
{
    public class WellnessTip
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}