using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolisticHealthHub.Pages
{
    public class IndexModel : PageModel
    {
        // Property pro uchov�n� dat pro ka�d� r�mec
        public string[] Informace { get; set; }

        public void OnGet()
        {
            // Zde m��eme nap��klad na��tat data z datab�ze nebo jin�ho �lo�i�t�
            // Pro demonstra�n� ��ely zde jednodu�e p�id�me statick� data
            Informace = new string[]
            {
                "Informace o fyzick� aktivit�",
                "Shrnut� du�evn�ho zdrav�",
                "Informace o pr�ci nebo �kole",
                "Informace o osobn�m rozvoji"
            };
        }
    }
}
