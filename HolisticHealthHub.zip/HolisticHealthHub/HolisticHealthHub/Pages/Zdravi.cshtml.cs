using HolisticHealthHub.Pages.Shared;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolisticHealthHub.Pages
{
    public class ZdraviModel : PageModel
    {
        public List<Terapeut> SeznamTerapeutu { get; set; }
        public List<WellnessTip> SeznamWellnessTipu { get; set; }
        public List<HealthArticle> SeznamZdravotnichClanku { get; set; }

        public void OnGet()
        {
            // Simulace na��t�n� terapeut�
            SeznamTerapeutu = new List<Terapeut>
            {
                new Terapeut { Jmeno = "Jan Nov�k", Specializace = "Psychoterapie", Kontakt = "jan.novak@example.com" },
                new Terapeut { Jmeno = "Eva Svobodov�", Specializace = "Fyzioterapie", Kontakt = "eva.svobodova@example.com" },
                new Terapeut { Jmeno = "Petr Dvo��k", Specializace = "Nutri�n� poradenstv�", Kontakt = "petr.dvorak@example.com" }
            };

            // Simulace na��t�n� wellness tip�
            SeznamWellnessTipu = new List<WellnessTip>
            {
                new WellnessTip { Title = "Tip 1", Description = "Popis tipu 1" },
                new WellnessTip { Title = "Tip 2", Description = "Popis tipu 2" },
                new WellnessTip { Title = "Tip 3", Description = "Popis tipu 3" }
            };

            // Simulace na��t�n� �l�nk� o zdrav�
            SeznamZdravotnichClanku = new List<HealthArticle>
            {
                new HealthArticle { Title = "�l�nek 1", Content = "Obsah �l�nku 1" },
                new HealthArticle { Title = "�l�nek 2", Content = "Obsah �l�nku 2" },
                new HealthArticle { Title = "�l�nek 3", Content = "Obsah �l�nku 3" }
            };
        }
    }
}
