﻿namespace HolisticHealthHub.Pages
{
    public class UserSettings
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        // Další vlastnosti pro další nastavení

        // Konstruktor pro inicializaci výchozích hodnot, pokud je to potřeba
        public UserSettings()
        {
            // Nastavte výchozí hodnoty
            FirstName = "";
            LastName = "";
            Email = "";
        }
    }
}