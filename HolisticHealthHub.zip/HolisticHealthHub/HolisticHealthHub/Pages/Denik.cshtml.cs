using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolisticHealthHub.Pages
{
    public class DenikModel : PageModel
    {
        private static List<DiaryEntry> _entries = new List<DiaryEntry>();

        [BindProperty]
        public DiaryEntry Entry { get; set; }

        public List<DiaryEntry> Entries => _entries;

        public string SearchQuery { get; set; }

        public IActionResult OnPost()
        {
            if (ModelState.IsValid)
            {
                SaveEntryToDatabase(Entry);
                return RedirectToPage();
            }
            else
            {
                return Page();
            }
        }

        public IActionResult OnPostEdit(int id)
        {
            var existingEntry = _entries.FirstOrDefault(e => e.Id == id);
            if (existingEntry != null)
            {
                existingEntry.Title = Entry.Title;
                existingEntry.Content = Entry.Content;
                return RedirectToPage();
            }
            else
            {
                return NotFound();
            }
        }

        public IActionResult OnPostDelete(int id)
        {
            var entryToDelete = _entries.FirstOrDefault(e => e.Id == id);
            if (entryToDelete != null)
            {
                _entries.Remove(entryToDelete);
            }
            return RedirectToPage();
        }

        public IActionResult OnPostSearch()
        {
            if (!string.IsNullOrEmpty(SearchQuery))
            {
                Entries.Clear(); // Vy�ist�me sou�asnou kolekci
                Entries.AddRange(_entries.Where(e => e.Title.Contains(SearchQuery) || e.Content.Contains(SearchQuery))); // P�id�me nov� z�znamy podle hledan�ho dotazu
            }
            else
            {
                Entries.Clear(); // Vy�ist�me sou�asnou kolekci
                Entries.AddRange(_entries); // P�id�me v�echny z�znamy zp�t
            }
            return Page();
        }

        private void SaveEntryToDatabase(DiaryEntry entry)
        {
            entry.Id = _entries.Any() ? _entries.Max(e => e.Id) + 1 : 1;
            _entries.Add(entry);
        }
    }

    public class DiaryEntry
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "N�zev je povinn�.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Obsah je povinn�.")]
        public string Content { get; set; }
    }
}

