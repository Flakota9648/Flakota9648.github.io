﻿namespace HolisticHealthHub.Pages
{
    public class Terapeut
    {
        public string Jmeno { get; set; }
        public string Specializace { get; set; }
        public string Kontakt { get; set; }
    }

}