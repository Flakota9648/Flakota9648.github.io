using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolisticHealthHub.Pages
{
    public class NastaveniModel : PageModel
    {
        [BindProperty]
        public UserSettings Settings { get; set; }

        public void OnGet()
        {
            // Simulace na�ten� existuj�c�ch nastaven� z datab�ze
            Settings = new UserSettings
            {
                FirstName = "Jan",
                LastName = "Nov�k",
                Email = "jan.novak@example.com"
            };

            // Zobrazen� potvrzovac� zpr�vy, pokud existuje
            if (TempData["Message"] != null)
            {
                ViewData["Message"] = TempData["Message"].ToString();
            }
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                // Pokud formul�� nen� platn�, z�sta�te na stejn� str�nce a zobrazte chyby
                return Page();
            }

            // Zde byste prov�d�li ulo�en� nastaven� do datab�ze

            // Po �sp�n�m ulo�en� m��ete p�esm�rovat u�ivatele na jinou str�nku
            TempData["Message"] = "Nastaven� bylo �sp�n� ulo�eno."; // Ulo�en� potvrzovac� zpr�vy do TempData
            return RedirectToPage("/Index"); // P�esm�rov�n� na domovskou str�nku
        }
    }
}
