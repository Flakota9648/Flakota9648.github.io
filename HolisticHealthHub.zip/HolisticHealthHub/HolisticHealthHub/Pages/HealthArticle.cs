﻿namespace HolisticHealthHub.Pages
{
    public class HealthArticle
    {
        public string Title { get; set; }
        public string Content { get; set; }
    }
}