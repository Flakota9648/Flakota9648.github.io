using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace HolisticHealthHub.Pages
{
    public class PojmyModel : PageModel
    {
  
    }
}

